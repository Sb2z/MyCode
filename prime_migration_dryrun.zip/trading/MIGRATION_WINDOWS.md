# MIGRATION WINDOWS — Prime Engine complet sur le PC fixe

Objectif : retrouver EXACTEMENT l'état actuel (watcher 24/7, feature store,
calendrier, trend-day, Research Lab nocturne, watchdog, pont TradingView)
sur le PC Windows, qui ne dort jamais.

## Le point technique n°1 : le chemin du projet

Tout le code utilise des chemins absolus `/Users/sam/trading/...`. Sur
Windows, Python résout ce chemin POSIX vers `<disque courant>:\Users\sam\trading`.
**Le projet DOIT donc être décompressé très exactement dans
`C:\Users\sam\trading`** (crée le dossier `C:\Users\sam` s'il n'existe pas —
peu importe ton nom d'utilisateur Windows, c'est juste un dossier), et tout
doit tourner depuis le disque C:. C'est l'astuce qui évite de refactorer
50 fichiers ; le refactor propre (PROJECT_ROOT configurable) pourra se faire
plus tard, il touchera des fichiers protégés (tokens).

## Étape 0 — Prérequis sur le PC Windows (30 min)

1. **Python 3.12+** (python.org) — cocher "Add python.exe to PATH".
   Vérifier : `python --version`.
2. **Git for Windows** (git-scm.com) — fournit Git Bash, nécessaire pour le
   hook constitutionnel (.githooks/pre-commit est un script bash ; git
   l'exécute via son sh intégré, `stat -c %Y` y fonctionne).
3. **Node.js LTS** (nodejs.org) — pour le pont TradingView et le CLI Claude.
4. **Claude Code CLI** : `npm install -g @anthropic-ai/claude-code`, puis
   `claude` une fois pour se connecter au compte.
5. **TradingView Desktop** : déjà installé ✅.
6. **Alimentation** : Paramètres → Système → Alimentation → Mise en veille :
   JAMAIS (secteur). C'est la raison d'être de la migration.

## Étape 1 — Le jour J : geler le Mac PUIS transférer (ordre critique)

⚠️ Deux watchers en parallèle = doubles alertes Telegram et journaux
divergents. On gèle le Mac AVANT de copier les données.

Sur le Mac (ou demande à Claude Code de le faire) :
```bash
bash /Users/sam/trading/windows/freeze_mac.sh
```
Ce script : arrête le watcher, retire les crontabs (watchdog + nightly),
et construit `~/Desktop/prime_migration.zip` (projet complet : git, .env,
journal.json, prime.duckdb, historiques — TOUT).

Transfert du zip vers le PC : clé USB, AirDrop→cloud, peu importe —
**le zip contient tes clés API (.env), ne le laisse pas traîner**.

## Étape 2 — Installation sur Windows (20 min)

```bat
rem 1. Décompresser dans C:\Users\sam\trading (chemin EXACT)
rem 2. Dépendances Python
cd /d C:\Users\sam\trading
pip install -r requirements.txt

rem 3. Hook constitutionnel (séparation des pouvoirs V3)
git config core.hooksPath .githooks

rem 4. Pont TradingView
cd tools\claudeverstradingview
npm install
```

Enregistrer le MCP TradingView pour Claude Code (PowerShell) :
```
claude mcp add --scope user claudeverstradingview -- node C:\Users\sam\trading\tools\claudeverstradingview\src\server.js
```

## Étape 3 — Les 4 tâches planifiées (remplacent screen + cron)

En **invite de commandes administrateur** :
```bat
C:\Users\sam\trading\windows\install_tasks.bat
schtasks /Run /TN "Prime Watcher"
```
Cela installe : watcher (au boot), watchdog (15 min), chercheur nocturne
(23h30), refresh data lake (07h00). Vérifier : `schtasks /Query | findstr Prime`.

## Étape 4 — TradingView + pont (à la demande, pas critique au boot)

L'indicateur Pine "Prime Trend Day Trigger" est dans TON COMPTE TradingView
(cloud) — il est déjà là sur le PC, rien à re-déployer.
Pour le pont CDP (parité, replay, dev Pine) :
```bat
C:\Users\sam\trading\tools\claudeverstradingview\scripts\launch_tv_debug.bat
```
puis `python scripts\compare_pine_parity.py` pour un check de parité.
Le watcher est 100% découplé du pont : TradingView fermé ne casse rien.

## Étape 5 — Checklist de validation (= "être exactement là où on en est")

| Vérification | Commande | Attendu |
|---|---|---|
| Watcher vivant | `type prime_watcher.log` (fin) | un cycle < 6 min, mêmes lignes que sur Mac |
| Telegram | `python notify.py` | message ✅ reçu |
| Journal intact | `python journal.py report` | mêmes stats que le Mac (93+ clôturés, dédup) |
| Feature store | `python feature_store.py` | compteur gate qui reprend où il était |
| Verdict V1 | `python resim_report.py` | tableau avant/après identique |
| Research Lab | `python harness.py` | compteurs 7 testées / 6 tuées |
| Calendrier | `python calendar_feed.py` | événements + pré-event |
| Watchdog | attendre 15 min | rien (ou ⚠️ si tu coupes le watcher exprès) |
| Lendemain matin | `research\reports\` | rapport de la session nocturne |

## Étape 6 — Décommission du Mac

Quand la checklist est verte 24h : le Mac garde sa copie comme backup
(elle est gelée, plus aucun process). Ne JAMAIS relancer le watcher Mac
sans avoir arrêté celui du PC.

## Différences connues Mac → Windows (toutes bénignes)

- Notifications macOS (osascript) → no-op silencieux sur Windows ; Telegram
  reste le canal principal (inchangé).
- Le message du watchdog mentionne la commande de relance `screen` du Mac —
  cosmétique, la relance Windows c'est `schtasks /Run /TN "Prime Watcher"`.
- `research/run_nightly.sh` (bash) remplacé par `windows\run_nightly.bat` +
  wrapper Python (timeout 45 min portable).
- Heure Paris : le code utilise UTC+2 fixe partout — comportement identique
  sur les deux machines (même approximation DST, assumée depuis V1).

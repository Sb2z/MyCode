"""Wrapper timeout 45 min de la session chercheur (portable Windows)."""
import datetime
import subprocess
import sys

PROMPT = """Tu es le chercheur nocturne du Prime Research Lab. Lis et applique
strictement research/RESEARCH_PROTOCOL.md (cycle: ingestion, autopsie, max 3
hypothèses nouvelles, expériences via harness.evaluate, rapport
research/reports/{date}.md + résumé Telegram 5 lignes via notify.send
silent=True). Tu n'écris QUE dans research/. Commit final de tes fichiers
research/ avec un message clair.""".format(date=datetime.date.today().isoformat())

print(f"{datetime.datetime.now():%F %T} — session chercheur démarrée")
try:
    r = subprocess.run(
        ["claude", "-p", PROMPT, "--permission-mode", "acceptEdits", "--max-turns", "80"],
        timeout=45 * 60, cwd=r"C:\Users\sam\trading", shell=True)
    rc = r.returncode
except subprocess.TimeoutExpired:
    print("TIMEOUT 45 min — session interrompue (budget)")
    rc = 124
print(f"{datetime.datetime.now():%F %T} — session terminée (exit {rc})")
sys.exit(rc)

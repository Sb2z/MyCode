@echo off
rem ── PRIME WATCHER — lancé par le Planificateur de tâches au démarrage ──
rem Équivalent Windows du screen primewatcher du Mac.
cd /d C:\Users\sam\trading
python -u prime_watcher.py >> prime_watcher.log 2>&1

#!/bin/bash
# ═══ GEL DU MAC + ARCHIVE DE MIGRATION — à lancer le jour J, AVANT Windows ═══
# Arrête tout ce qui écrit (watcher, crons), puis zippe l'état EXACT.
set -u
cd /Users/sam/trading || exit 1

echo "1. Arrêt du watcher..."
screen -S primewatcher -X quit 2>/dev/null
sleep 1
pkill -f "prime_watcher.py" 2>/dev/null
sleep 1

echo "2. Retrait des crontabs (watchdog + nightly)..."
crontab -l 2>/dev/null | grep -vE "watchdog.py|run_nightly.sh" | crontab -

echo "3. Pause du Research Lab (au cas où)..."
touch research/PAUSE

echo "4. Archive complète (git + données + .env + duckdb)..."
ZIP=~/Desktop/prime_migration_$(date +%Y%m%d_%H%M).zip
cd /Users/sam
zip -rq "$ZIP" trading \
  -x "trading/tools/claudeverstradingview/node_modules/*" \
  -x "trading/__pycache__/*" -x "trading/*/__pycache__/*" \
  -x "trading/tools/claudeverstradingview/screenshots/*"

echo ""
echo "✅ Mac gelé. Archive : $ZIP ($(du -h "$ZIP" | cut -f1))"
echo "   ⚠️ Elle contient .env (clés API) — transfert privé uniquement."
echo "   Sur Windows : décompresser dans C:\\Users\\sam\\trading puis"
echo "   suivre MIGRATION_WINDOWS.md étape 2. Supprimer research/PAUSE"
echo "   sur le PC une fois la checklist verte."

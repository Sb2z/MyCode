@echo off
rem ═══ Installation des tâches planifiées du Prime Engine (lancer en admin) ═══

rem 1. Watcher : au démarrage de la machine, relance auto si crash
schtasks /Create /F /TN "Prime Watcher" /SC ONSTART /RU "%USERNAME%" ^
  /TR "C:\Users\sam\trading\windows\start_watcher.bat"

rem 2. Watchdog : toutes les 15 minutes
schtasks /Create /F /TN "Prime Watchdog" /SC MINUTE /MO 15 ^
  /TR "C:\Users\sam\trading\windows\run_watchdog.bat"

rem 3. Chercheur nocturne : 23h30
schtasks /Create /F /TN "Prime Research Nightly" /SC DAILY /ST 23:30 ^
  /TR "C:\Users\sam\trading\windows\run_nightly.bat"

rem 4. Data lake : refresh quotidien 07h00
schtasks /Create /F /TN "Prime Datalake" /SC DAILY /ST 07:00 ^
  /TR "cmd /c cd /d C:\Users\sam\trading && python research\datalake.py refresh >> research\datalake.log 2>&1"

echo.
echo Taches installees. Demarrer le watcher maintenant :
echo   schtasks /Run /TN "Prime Watcher"

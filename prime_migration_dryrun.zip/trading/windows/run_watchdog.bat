@echo off
cd /d C:\Users\sam\trading
python watchdog.py >> watchdog.log 2>&1

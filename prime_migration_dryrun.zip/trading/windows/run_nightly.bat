@echo off
rem ── Session chercheur nocturne (23h30) — équivalent research/run_nightly.sh ──
cd /d C:\Users\sam\trading
if exist research\PAUSE (
  echo %date% %time% PAUSE present - session annulee >> research\nightly.log
  exit /b 0
)
python windows\run_nightly_wrapper.py >> research\nightly.log 2>&1

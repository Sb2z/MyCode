# AUTOPSIE — prévu vs réalisé, jour par jour (append-only)

## 2026-06-10 (premier run, manuel)

- **Trend-day GOLD SHORT armé 01:20** (ADX 43.3, ER 0.455, prix 4233) :
  à 08h le régime était dégradé en TENDANCE HACHÉE (ER 0.40→0.25), aucun
  follow-through propre. Verdict : armement overnight sur liquidité fine,
  non confirmé en session. Question ouverte → backlog : "les armements
  overnight (22h-08h) sous-performent-ils ceux de session ?" (besoin de
  plus d'armements pour tester — compter d'abord).
- **Prime** : aucun A_SETUP depuis le 09/06 23:25 (veto session OVERNIGHT
  a tué les setups nocturnes US500 — comportement voulu post-V1).
- **PAPER** : aucune stratégie active (les tests synthétiques du juge ont
  été retirés).
- **Contexte macro** : jour CPI (14:30 Paris). Veto PRÉ-EVENT attendu à
  14:00 — première validation live de la chaîne calendrier (A3/V2).

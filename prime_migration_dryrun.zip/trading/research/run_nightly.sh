#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════
# RUN NIGHTLY — session chercheur autonome du Prime Research Lab (V3 étape 6)
#
# Lancé par cron à 23h30 Paris. Garde-fous :
#   • kill switch : research/PAUSE existe → pas de session
#   • durée max 45 min (timeout python, portable macOS)
#   • max-turns plafonné (budget)
#   • le chercheur n'écrit que dans research/ — les fichiers protégés sont
#     verrouillés par le hook constitutionnel quoi qu'il arrive
# ═══════════════════════════════════════════════════════════════════════════
set -u
cd /Users/sam/trading || exit 1
export PATH=/opt/homebrew/bin:/opt/homebrew/opt/python@3.14/bin:$PATH

if [ -f research/PAUSE ]; then
  echo "$(date '+%F %T') PAUSE présent — session annulée"
  exit 0
fi

echo "$(date '+%F %T') — session chercheur démarrée"

PROMPT="Tu es le chercheur nocturne du Prime Research Lab. Lis et applique
strictement research/RESEARCH_PROTOCOL.md (cycle: ingestion, autopsie, max 3
hypothèses nouvelles, expériences via harness.evaluate, rapport
research/reports/$(date +%F).md + résumé Telegram 5 lignes via notify.send
silent=True). Tu n'écris QUE dans research/. Commit final de tes fichiers
research/ avec un message clair."

# Timeout 45 min portable (macOS n'a pas coreutils timeout)
python3 - "$PROMPT" <<'PYEOF'
import subprocess, sys
try:
    r = subprocess.run(
        ["claude", "-p", sys.argv[1],
         "--permission-mode", "acceptEdits",
         "--max-turns", "80"],
        timeout=45 * 60, cwd="/Users/sam/trading")
    sys.exit(r.returncode)
except subprocess.TimeoutExpired:
    print("TIMEOUT 45 min — session interrompue (budget)")
    sys.exit(124)
PYEOF
rc=$?
echo "$(date '+%F %T') — session terminée (exit $rc)"

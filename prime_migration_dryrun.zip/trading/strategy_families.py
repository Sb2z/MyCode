#!/usr/bin/env python3
"""STRATEGY FAMILIES — bibliothèque de signaux partagée juge/production.

SOURCE UNIQUE : le harness (backtest) et le watcher (shadow PAPER) évaluent
les stratégies via build_signal(family, params) — le même code des deux
côtés, donc aucun écart backtest/production possible par construction.

Le chercheur autonome compose des stratégies en CHOISISSANT famille +
paramètres. Ajouter une nouvelle famille = modifier ce fichier = token
humain requis (fichier protégé par le hook constitutionnel).

Interface d'un signal :
  fn(window, ctx=None) -> "LONG" | "SHORT" | None
  window : liste de bougies [ts, o, h, l, c, v] se terminant à la bougie de
           décision (close connue). AUCUN accès au futur : l'entrée se fait
           à l'open de la bougie suivante (géré par le harness/shadow).
  ctx    : dict optionnel (session, cot_pctile, event_mode...) — peut être
           absent, les familles doivent dégrader proprement.
"""

import datetime as dt

PARIS_OFFSET_H = 2  # approximation projet (cohérente avec le reste du code)


def _paris_hour(ts_epoch):
    return (dt.datetime.fromtimestamp(ts_epoch, dt.timezone.utc)
            + dt.timedelta(hours=PARIS_OFFSET_H)).hour


def _ret_pct(window, k):
    if len(window) < k + 1:
        return None
    a, b = float(window[-1 - k][4]), float(window[-1][4])
    return (b - a) / a * 100 if a else None


def _momentum(params):
    k = int(params.get("k", 4))
    thr = float(params.get("thr_pct", 0.3))

    def fn(window, ctx=None):
        r = _ret_pct(window, k)
        if r is None:
            return None
        if r > thr:
            return "LONG"
        if r < -thr:
            return "SHORT"
        return None
    return fn


def _mean_reversion(params):
    k = int(params.get("k", 4))
    thr = float(params.get("thr_pct", 0.5))

    def fn(window, ctx=None):
        r = _ret_pct(window, k)
        if r is None:
            return None
        if r > thr:
            return "SHORT"
        if r < -thr:
            return "LONG"
        return None
    return fn


def _session_hour(params):
    start = int(params.get("start", 15))
    end = int(params.get("end", 17))
    direction = params.get("direction", "LONG")

    def fn(window, ctx=None):
        h = _paris_hour(float(window[-1][0]))
        in_win = start <= h < end if start < end else (h >= start or h < end)
        return direction if in_win else None
    return fn


def _er_kaufman(closes, n=39):
    """Efficiency Ratio (même formule que regime.efficiency_ratio)."""
    if len(closes) < n + 1:
        return None
    net = abs(closes[-1] - closes[-1 - n])
    path = sum(abs(closes[i] - closes[i - 1]) for i in range(len(closes) - n, len(closes)))
    return net / path if path else 0.0


def _wilder_adx(window, n=14):
    """ADX Wilder autosuffisant (pas de dépendance non protégée)."""
    if len(window) < 2 * n + 1:
        return None
    highs = [float(c[2]) for c in window]
    lows = [float(c[3]) for c in window]
    closes = [float(c[4]) for c in window]
    trs, pdms, mdms = [], [], []
    for i in range(1, len(window)):
        trs.append(max(highs[i] - lows[i], abs(highs[i] - closes[i - 1]),
                       abs(lows[i] - closes[i - 1])))
        up, dn = highs[i] - highs[i - 1], lows[i - 1] - lows[i]
        pdms.append(up if up > dn and up > 0 else 0.0)
        mdms.append(dn if dn > up and dn > 0 else 0.0)
    # Lissage Wilder
    atr, pdi_s, mdi_s = sum(trs[:n]), sum(pdms[:n]), sum(mdms[:n])
    dxs = []
    for i in range(n, len(trs)):
        atr = atr - atr / n + trs[i]
        pdi_s = pdi_s - pdi_s / n + pdms[i]
        mdi_s = mdi_s - mdi_s / n + mdms[i]
        if atr <= 0:
            continue
        pdi, mdi = 100 * pdi_s / atr, 100 * mdi_s / atr
        if pdi + mdi > 0:
            dxs.append(100 * abs(pdi - mdi) / (pdi + mdi))
    if len(dxs) < n:
        return None
    adx = sum(dxs[:n]) / n
    for x in dxs[n:]:
        adx = (adx * (n - 1) + x) / n
    return adx


def _momentum_regime(params):
    """Momentum CONDITIONNEL au régime de tendance propre (ER + ADX).

    Famille approuvée par Sam le 10/06/2026 (backlog run n°1) : teste si
    l'edge trend-day (momentum quand ER>seuil et ADX>seuil) se généralise.
    """
    k = int(params.get("k", 4))
    thr = float(params.get("thr_pct", 0.3))
    er_min = float(params.get("er_min", 0.45))
    adx_min = float(params.get("adx_min", 30.0))
    er_n = int(params.get("er_n", 39))
    adx_n = int(params.get("adx_n", 14))

    def fn(window, ctx=None):
        r = _ret_pct(window, k)
        if r is None:
            return None
        closes = [float(c[4]) for c in window]
        er = _er_kaufman(closes, er_n)
        adx = _wilder_adx(window, adx_n)
        if er is None or adx is None or er < er_min or adx < adx_min:
            return None
        if r > thr:
            return "LONG"
        if r < -thr:
            return "SHORT"
        return None
    return fn


def _cot_extreme(params):
    lo = float(params.get("lo_pctile", 10))
    hi = float(params.get("hi_pctile", 90))
    mode = params.get("mode", "contrarian")  # contrarian | follow

    def fn(window, ctx=None):
        p = (ctx or {}).get("cot_pctile")
        if p is None:
            return None
        if p <= lo:
            return "LONG" if mode == "contrarian" else "SHORT"
        if p >= hi:
            return "SHORT" if mode == "contrarian" else "LONG"
        return None
    return fn


FAMILIES = {
    "momentum": _momentum,
    "mean_reversion": _mean_reversion,
    "session_hour": _session_hour,
    "cot_extreme": _cot_extreme,
    "momentum_regime": _momentum_regime,
}


def build_signal(family, params):
    if family not in FAMILIES:
        raise ValueError(f"famille inconnue: {family} (disponibles: {sorted(FAMILIES)})")
    return FAMILIES[family](params or {})


if __name__ == "__main__":
    import json
    print("familles:", sorted(FAMILIES))
    fn = build_signal("momentum", {"k": 3, "thr_pct": 0.2})
    demo = [[i * 60, 100, 101, 99, 100 + i * 0.1, 0] for i in range(10)]
    print("momentum sur série montante:", fn(demo))

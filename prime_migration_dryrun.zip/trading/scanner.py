#!/usr/bin/env python3
"""
SCANNER — Détecteur de setups PROPRES à RR élevé (mode "pas scalp")
══════════════════════════════════════════════════════════════════
Quand le régime n'est PAS scalp-friendly (haché/range), on bascule en mode SETUP :
moins de trades, mais PROPRES — confluence totale (macro, news, options, SMC, order
flow) + entrée sur zone de confluence + RR ≥ 2. Objectif : 3-5 trades de qualité/jour.

Un setup PROPRE = confluence ≥ 6.5 + plusieurs couches alignées sur une ZONE
(OTE + OB + Fib + mur options + POC) + cible logique donnant RR ≥ 2.
Le scanner est ÉVOLUTIF : il re-tourne et s'adapte au contexte.
"""

import clusters
import costs

RR_MIN_SETUP = 2.0
CONF_MIN = 6.5
STOP_ATR_FLOOR = 0.6      # stop minimum en multiple d'ATR15m (proxy clusters.ATR15M_PCT)
MAX_COST_SHARE = 0.15     # spread+slippage ne doivent pas dépasser 15% du stop


def _collect_targets(R, direction):
    """Niveaux logiques de cible dans le sens du trade (options, POC, Fib, VAL/VAH)."""
    price = R.get("price")
    lv = []
    op = R.get("options") or {}
    of = R.get("orderflow") or {}
    fibs = R.get("fibs") or {}
    cands = []
    for v in (op.get("max_pain_u") or op.get("max_pain"), op.get("put_wall_u") or op.get("put_wall"),
              op.get("call_wall_u") or op.get("call_wall"), of.get("poc"), of.get("vah"), of.get("val")):
        if v: cands.append(v)
    for v in (fibs or {}).values():
        if isinstance(v, (int, float)): cands.append(v)
    for c in cands:
        if direction == "LONG" and c > price:
            lv.append(c)
        elif direction == "SHORT" and c < price:
            lv.append(c)
    lv.sort(reverse=(direction == "SHORT"))
    return lv


def quality_setup(R, asset):
    """Construit le meilleur setup propre pour un actif, ou None."""
    conf = R.get("confluence", {})
    score = conf.get("score", 0)
    direction = conf.get("direction")
    if score < CONF_MIN or direction not in ("LONG", "SHORT"):
        return None
    strat = R.get("strategy") or {}
    lv = strat.get("levels") or {}
    ote = strat.get("ote") or {}
    if not lv:
        return None
    entry = ote.get("sweet_spot") or lv.get("entry")
    stop = lv.get("stop")
    if not entry or not stop:
        return None
    sign = 1 if direction == "LONG" else -1
    risk = abs(entry - stop)
    if risk <= 0:
        return None
    # Plancher de stop : un stop plus serré que 0.6 x ATR15m OU dont les coûts
    # (spread+slippage) mangent plus de 15% est dans le bruit du spread
    # (A_SETUP du 9 juin : 8 points sur US500). On élargit et on recalcule le
    # RR ; si le RR retombe sous 2, le setup est rejeté plus bas.
    stop_widened = False
    atr15m = entry * clusters.ATR15M_PCT.get(asset, 0.20) / 100
    cost_floor = (costs.spread_points(asset, "SESSION", entry)
                  + costs.slippage_points(asset, entry)) / MAX_COST_SHARE
    floor = max(STOP_ATR_FLOOR * atr15m, cost_floor)
    if risk < floor:
        stop = round(entry - sign * floor, 2)
        risk = abs(entry - stop)
        stop_widened = True
    # Cible : le 1er niveau logique donnant RR >= 2 ; sinon le plus loin
    targets = _collect_targets(R, direction)
    tp = None
    for t in targets:
        if abs(t - entry) / risk >= RR_MIN_SETUP:
            tp = t; break
    if tp is None and targets:
        tp = targets[-1]
    if tp is None:
        tp = round(entry + sign * RR_MIN_SETUP * risk, 2)
    rr = round(abs(tp - entry) / risk, 2)
    if rr < RR_MIN_SETUP:
        return None

    # Compter les couches alignées (qualité de confluence)
    aligned = conf.get("aligned", "?")
    rg = R.get("regime_scalp") or {}
    strat_name = (R.get("strategy") or {}).get("name")
    return {"asset": asset, "direction": direction, "conf": score, "aligned": aligned,
            "entry": round(entry, 2), "stop": round(stop, 2), "tp": round(tp, 2), "rr": rr,
            "stop_widened": stop_widened,
            "regime": rg.get("regime"), "strategy": strat_name, "drivers": _drivers(R)}


def _drivers(R):
    out = []
    ms = R.get("macro", {}).get("score", {})
    for n, txt, s in ms.get("signals", []):
        if s != 0:
            out.append(("🔴" if s < 0 else "🟢") + " " + txt)
    op = R.get("options")
    if op:
        out.append(f"🎰 Max Pain {op.get('max_pain_u') or op.get('max_pain')} · régime {op.get('gex_regime','')[:18]}")
    return out[:5]


def scan():
    setups = []
    regimes = {}
    for asset in ("GOLD", "US500"):
        try:
            if asset == "GOLD":
                import aurum
                R = aurum.run_analysis(verbose=False)
            else:
                import sentinel500
                R = sentinel500.run_analysis(verbose=False)
        except Exception:
            continue
        regimes[asset] = R.get("regime_scalp") or {}
        s = quality_setup(R, asset)
        if s:
            setups.append(s)
    setups.sort(key=lambda x: (x["conf"], x["rr"]), reverse=True)
    return {"setups": setups, "regimes": regimes}


if __name__ == "__main__":
    r = scan()
    print("═" * 64)
    print("  🎯 SCANNER SETUPS PROPRES (mode qualité, RR ≥ 2)")
    print("═" * 64)
    for a, rg in r["regimes"].items():
        mode = "SCALP" if rg.get("scalp_ok") else "SETUP (pas scalp)"
        print(f"  {a}: régime {rg.get('regime','?')} → mode {mode}")
    if not r["setups"]:
        print("\n  ⏳ Aucun setup propre (confluence<6.5 ou RR<2) — on ATTEND. Patience = qualité.")
    else:
        for s in r["setups"]:
            print(f"\n  {'🟢' if s['direction']=='LONG' else '🔴'} {s['asset']} {s['direction']} — confluence {s['conf']}/10 (alignés {s['aligned']})")
            print(f"     Entrée {s['entry']} · Stop {s['stop']} · TP {s['tp']} · RR {s['rr']}:1")
            for d in s["drivers"]:
                print(f"     {d}")
    print("═" * 64)

# 🛡️ SENTINEL-500 — Leçons de trading (mémoire permanente)

Leçons gagnées en argent réel sur la phase GOLD (29 mai 2026), conservées et appliquées au S&P 500.
Ces règles sont **codées dans le moteur** (sentinel500.py, track.py, journal.py).

## Règles de discipline (non négociables)

1. **ANTI-FADE** — Ne jamais prendre une position contre-tendance quand l'ADX > 35.
   *Preuve : SHORT GOLD $4,529 contre un ADX 40 → stoppé sur squeeze (-$9).*

2. **NE PAS CHASSER l'OB/OS** — Si RSI > 70 ou StochK > 90, pas d'entrée au marché.
   Attendre le pullback (Fibonacci 0.382–0.618).
   *Preuve : les longs chassés au sommet OB se font balayer.*

3. **ALIGNEMENT HTF** — Un trade intraday contre le 1D (timeframe supérieur) = conviction réduite.
   *Preuve : LONG GOLD $4,555 alors que le 1D était baissier → perte. Le HTF gagne.*

4. **TIMING / VENDREDI** — Pas de nouvelle position fraîche tard le vendredi (squaring de fin
   de semaine + risque de gap week-end). Toujours afficher la VALIDITÉ d'un setup.
   *Preuve : LONG $4,555 donné à 18h51 vendredi → retournement.*

5. **NE PAS ACHETER LA QUEUE D'UN MOVE ÉTENDU** — Après un mouvement vertical sans
   consolidation, le risque de mean-reversion est élevé même avec la tendance.

6. **STOPS CALIBRÉS À L'ATR** — Stops trop serrés = balayés sur les mèches.
   Calibrer à la volatilité réelle (ATR), pas à un % fixe arbitraire.

7. **PRIX > NARRATIVE** — Quand le prix/ADX contredisent une thèse macro, le prix gagne
   à court terme. Pondérer le live, pas les biais codés en dur périmés.

## Méthode (ce qui a marché)

- **LONG avec-tendance sur pullback** dans un ADX fort = le trade gagnant validé (+$23).
- **Journal forward-test** : chaque trade noté contre le prix réel, win rate honnête.
- **News live (Finnhub)** : a renversé un biais faux. Toujours brancher le temps réel.
- **Séparer trades IA vs trades USER** + commentaire de contexte sur chacun.
- **Anti-surajustement** : ne jamais entraîner l'IA sur 1-2 trades. Min 5 trades cohérents.

## Protocole Prime / Edge vivant

- Le moteur doit rester **adaptatif**, mais pas instable : on modifie les règles seulement
  quand le journal montre un edge robuste, pas après une seule bonne journée.
- Chaque nouvel edge candidat doit passer par `edge_lab.py` :
  minimum d'échantillon, split temporel 60/40, espérance positive, puis shrinkage des
  petits échantillons. Les catégories sont `KEEP`, `WATCH`, `AVOID`.
- Le mode Prime privilégie actuellement les setups à **TP1** car le backtest récent montre
  que TP1 bat TP2 sur les signaux IA. Ce n'est pas un dogme : si les données futures
  changent, le moteur doit le détecter.
- Les signaux doivent être séparés en trois états : `A_SETUP`, `WATCH`, `NO_TRADE`.
  L'absence de trade est une décision active quand le régime est range/haché ou que le
  RR/contexte n'est pas suffisant.
- Objectif permanent : maximiser l'edge réel en intégrant macro, news, options, SMC,
  order flow, régime et performance mesurée, sans empiler des filtres qui ne sont pas
  validés hors échantillon.
- En levier x20, le moteur est orienté profit mais pas "all-in" : chaque setup doit afficher
  le rendement cible x20, la perte x20 au SL, et une taille de marge maximale pour capper
  le risque compte. Le target n'est pas dogmatique : TP1/TP2 est choisi par l'espérance du
  journal et peut basculer si les données futures montrent un meilleur profit ajusté du risque.
- Auto-correction d'edge : toute evolution doit etre recomparee au baseline via
  `adaptive_edge.py` en capital final x20. Le moteur peut reduire le nombre de trades,
  filtrer un actif, un sens, une strategie, une session ou une plage horaire seulement si
  cette restriction bat le baseline avec assez de donnees et un split train/test positif.

## Spécifique S&P 500 (vs GOLD)

- Signes **cohérents** (pas les paradoxes de l'or) :
  - Risk-off (VIX↑, géo) = **baissier** actions (inverse de l'or).
  - Inflation chaude = **baissier** (Fed restrictive) — régime "good is bad".
  - Fed dovish / inflation froide = **haussier**.
  - VIX = corrélation inverse #1. NASDAQ = leader. Taux↑ = pression valorisations.
- Catalyseurs : FOMC, CPI/PCE, NFP, ISM, retail sales, saison des earnings, Powell.

## 📊 ANALYSE DES 57 TRADES RÉELS DE SAM (relevé Revolut, mai-juin 2026)

**Règle RR ≥ 2 SUPPRIMÉE** — les données le confirment : ce n'est PAS le ratio qui fait
gagner Sam, c'est l'analyse globale + le bon contexte. RR = info, pas un filtre.

### L'EDGE de Sam (validé statistiquement) :
1. **SHORT > LONG** : shorts 70% WR (+0.21%/trade, n=47) · longs 58% WR (-0.09%, n=26).
   → Les LONGS sont la fuite (perte moy -0.47%, 2.6× les gains). Être TRÈS sélectif en long.
2. **GOLD = le terrain de jeu** (50 trades). Mais avec discipline : c'est le SHORT gold en
   downtrend qui paie.
3. **ÉVITER les actions individuelles** : AVGO -1.40%, AMD -1.54%, TSLA ~0. = la zone de perte.
   Rester sur GOLD + indices (US500 69% WR), pas les single stocks.
4. **TENDANCE FORTE = WIN** : downtrend +0.77% · ADX>35 +0.65% · ADX 20-30 +0.47%.
   → Trader AVEC une tendance établie, pas le range.

### Le jour d'OVERPERFORMANCE (vendredi 5 juin, +30% capital) :
- 19 trades en 1 jour, **17W/2L = 89% WR**.
- Contexte : jour NFP, GOLD en LIQUIDATION (downtrend violent, ADX 50).
- Méthode : **scalper les MICRO-REBONDS short AVEC la tendance baissière**, sortie rapide.
- LEÇON CLÉ : quand le marché a une direction FORTE (high ADX), la haute fréquence de
  micro-rebonds scalpés DANS le sens de la tendance = win rate explosif (89%). C'est SA
  meilleure stratégie. Le système doit la détecter et l'encourager ces jours-là.

### Ce que le système doit faire désormais :
- Privilégier les SHORTS gold en downtrend/ADX fort (son edge prouvé).
- Filtrer/déconseiller les LONGS sauf confluence très forte, et les single stocks.
- Les jours de tendance forte (ADX>30) : passer en mode scalp micro-rebond haute fréquence.
- Ne PAS imposer de RR — décider sur l'analyse globale (confluence + SMC + order flow + macro).

## 10 juin 2026 — Premiers tests live du Prime Engine V2

- **Trend day trigger, 1er armement réel** : GOLD SHORT à 01:20 Paris
  (ADX15m 43.3, ER 0.455, 15m/1h alignés, prix 4233). Alerte Telegram reçue.
  Observation : à 08h le régime s'était dégradé en TENDANCE HACHÉE — un
  armement overnight (liquidité fine) peut ne pas tenir jusqu'à la session
  active. À surveiller sur le forward-test : compter combien d'armements
  overnight survivent jusqu'à Londres/NY avant d'en faire une règle.
  (Conséquence pratique : alertes trend-day silencieuses entre 22h et 8h.)
- **Test CPI 14h30 — VALIDÉ EN RÉEL** : à 14h03 le radar a basculé
  🔴 PRÉ-EVENT et l'A_SETUP US500 SHORT actif depuis 13h51 (conf 8.7,
  RR 2.33) est passé NO_TRADE sous veto, 27 minutes avant le print.
  Première validation bout-en-bout de la chaîne calendrier→radar→veto
  en conditions réelles. Leçon : le système refuse maintenant de signaler
  un setup à l'aveugle devant un chiffre majeur — exactement le
  comportement qui manquait les jours type NFP/CPI.
  Limite connue du jour : surprise_z=None sur ce CPI (l'historique des
  surprises démarre aujourd'hui, 4 observations minimum requises) — le
  mode EVENT_DAY ne pouvait pas s'armer, seul le veto pré-event était
  testable. L'historique se remplit à partir de ce soir (job actuals 15h15).

## Parité Pine (MISSION_PINE_TRIGGER)

Run 1 — 10 juin 2026 ~12:30 Paris (Python n_bars 15m = 150) :

```
  GOLD — PASS ✅        Python    Pine
  adx                     34.1   34.11
  er                     0.207   0.207
  dir15/dir1h      SHORT/SHORT   idem
  armed                  False   False

  US500 — PASS ✅       Python    Pine
  adx                     38.5    38.6
  er                     0.213     0.2
  dir15/dir1h      SHORT/SHORT   idem
  armed                  False   False
```

- Premier essai en 60 barres : FAIL GOLD (ΔADX 3.3, ΔER 0.049) → c'était le
  seeding Wilder + l'écart temporel des lectures, PAS un bug de formule.
  150 barres + lectures dos à dos → Δ ADX 0.01. Le Pine n'a pas été modifié.
- CONSÉQUENCE À TRAITER : trend_day_trigger.py vit encore sur 60 barres 15m
  → son ADX live porte ~2-3 pts de biais de seeding vs le vrai Wilder.
  Passer le fetch à 150 barres = correction de justesse (pas un changement
  de seuil), à faire après le run 2 de parité.
- Règle des deux canaux : Telegram (Python) et push TradingView (Pine) doivent
  parler ensemble. Si l'un se tait pendant que l'autre parle → panne d'un des
  deux systèmes, vérifier avant de trader.

Run 2 — 10 juin 2026 ~13:45 Paris (1h15 après le run 1) :

```
  GOLD — PASS ✅        Python    Pine
  adx                     33.2    33.2
  er                     0.104   0.104
  dir15/dir1h    NEUTRAL/SHORT   idem
  armed                  False   False

  US500 — PASS ✅       Python    Pine
  adx                     41.3    41.3
  er                     0.307     0.3
  dir15/dir1h      SHORT/SHORT   idem
  armed                  False   False
```

PARITÉ VALIDÉE : 2 runs PASS espacés >1h, ADX au dixième près, ER au
millième, y compris sur un état différent du run 1 (GOLD passé NEUTRAL 15m
entre-temps — les deux systèmes ont bougé ENSEMBLE). Critère d'acceptation
de l'étape 2 rempli. Étape 3 (alertes TV) : en attente du feu vert de Sam.

#!/usr/bin/env python3
"""NOTIFY — alertes Telegram du Prime Engine.

Token et chat_id dans .env (TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID — jamais en
clair dans le repo). Sans credentials, send() est un no-op silencieux : le
watcher ne casse pas, le log reste la source fiable.

Utilisé par le watcher pour : A_SETUP Prime, trend-day armé, fenêtre
pré-event, résumé quotidien. SIGNAL-ONLY : aucune action de trading, jamais.
"""

import json
import os
import urllib.parse
import urllib.request

ENV = "/Users/sam/trading/.env"


def _key(name):
    v = os.environ.get(name)
    if v:
        return v.strip()
    try:
        for line in open(ENV):
            if line.strip().startswith(name):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    except Exception:
        pass
    return None


def send(text, silent=False, timeout=10):
    """Envoie un message Telegram. Retourne True si accepté par l'API."""
    token = _key("TELEGRAM_BOT_TOKEN")
    chat_id = _key("TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        return False
    try:
        data = urllib.parse.urlencode({
            "chat_id": chat_id,
            "text": text[:4000],
            "disable_notification": "true" if silent else "false",
        }).encode()
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{token}/sendMessage", data=data)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return bool(json.loads(r.read().decode()).get("ok"))
    except Exception:
        return False


if __name__ == "__main__":
    ok = send("✅ Prime Engine — canal d'alerte Telegram opérationnel.\n"
              "Tu recevras ici : A_SETUP, mode scalp-tendance, pré-event macro, "
              "résumé quotidien. Signal-only, aucune exécution automatique.")
    print("envoi:", "OK" if ok else "ÉCHEC (credentials manquants ou API)")

#!/usr/bin/env python3
"""WATCHDOG — détecte un watcher mort silencieusement.

Le risque couvert : le prime_watcher plante ou gèle, et le silence Telegram
ressemble à "pas de setup" alors que c'est "système éteint". Lancé par cron
toutes les 15 min : si prime_watcher.log n'a pas bougé depuis >12 min
(cycle = 5 min), alerte Telegram. Anti-spam : une alerte par épisode de
silence, rappel toutes les 2h max. Une alerte de rétablissement quand le
log revit.

Remplace gratuitement le seul vrai avantage des alertes TradingView payantes
(canal indépendant du process watcher) — sauf le cas "Mac entièrement
éteint", accepté pendant Gate 1.
"""

import datetime as dt
import json
import os

import notify

LOG_FILE = "/Users/sam/trading/prime_watcher.log"
STATE_FILE = "/Users/sam/trading/watchdog_state.json"
STALE_AFTER_S = 12 * 60
REMIND_EVERY_S = 2 * 3600


def main():
    now = dt.datetime.now(dt.timezone.utc).timestamp()
    try:
        age = now - os.path.getmtime(LOG_FILE)
    except FileNotFoundError:
        age = float("inf")

    try:
        with open(STATE_FILE) as f:
            state = json.load(f)
    except Exception:
        state = {"silent": False, "last_alert": 0}

    if age > STALE_AFTER_S:
        if not state["silent"] or now - state["last_alert"] > REMIND_EVERY_S:
            notify.send(
                f"⚠️ WATCHER MUET depuis {age/60:.0f} min — le silence n'est pas "
                f"'pas de setup', c'est 'système éteint'. Relancer :\n"
                f"screen -dmS primewatcher bash -lc 'cd /Users/sam/trading && "
                f"exec python3.14 -u prime_watcher.py >> prime_watcher.log 2>&1'")
            state = {"silent": True, "last_alert": now}
    elif state.get("silent"):
        notify.send("✅ Watcher de nouveau actif.", silent=True)
        state = {"silent": False, "last_alert": 0}

    with open(STATE_FILE, "w") as f:
        json.dump(state, f)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Simulation de portefeuille sur les signaux IA du journal.

Par défaut: mois courant, signaux IA, doublons de scans fusionnés.
Deux courbes:
  • TP1: sortie au TP1, SL prioritaire si touché
  • TP2: sortie au TP2, SL prioritaire si touché

Les trades sans TP/SL touché restent à 0% dans la courbe stricte.
"""

import csv
import datetime as dt
import json
import sys

JOURNAL = "/Users/sam/trading/journal.json"


def load_trades(year, month, asset=None, dedup=True):
    data = json.load(open(JOURNAL))
    trades = []
    seen = set()
    for t in data.get("signals", []):
        try:
            ts = dt.datetime.fromisoformat(t.get("ts", ""))
        except Exception:
            continue
        trader = t.get("trader") or ("USER" if t.get("source") == "REAL_TRADE" else "AI")
        if ts.year != year or ts.month != month or trader != "AI":
            continue
        if asset and t.get("asset") != asset:
            continue
        key = (
            t.get("asset"),
            t.get("direction"),
            round(t.get("entry") or 0, 2),
            round(t.get("stop") or 0, 2),
            round(t.get("tp1") or 0, 2),
            round(t.get("tp2") or 0, 2),
        )
        if dedup and key in seen:
            continue
        seen.add(key)
        trades.append(t)
    trades.sort(key=lambda x: x.get("ts", ""))
    return trades


def outcome(t, target):
    if t.get("status") == "OPEN":
        return "OPEN", 0.0, None
    entry = t.get("entry")
    stop = t.get("stop")
    tp = t.get(target)
    hi = t.get("hi_since")
    lo = t.get("lo_since")
    direction = t.get("direction")
    if None in (entry, stop, tp, hi, lo) or direction not in ("LONG", "SHORT"):
        return "NO_DATA", 0.0, None
    sign = 1 if direction == "LONG" else -1
    sl_hit = lo <= stop if sign > 0 else hi >= stop
    tp_hit = hi >= tp if sign > 0 else lo <= tp
    # Conservateur: si SL et TP sont tous les deux observés dans la fenêtre, SL gagne.
    if sl_hit:
        return "SL", sign * (stop - entry) / entry * 100, stop
    if tp_hit:
        return "TP", sign * (tp - entry) / entry * 100, tp
    return "NO_HIT", 0.0, None


def simulate(trades, target, start=100.0):
    equity = start
    rows = []
    counts = {"TP": 0, "SL": 0, "NO_HIT": 0, "OPEN": 0, "NO_DATA": 0}
    for i, t in enumerate(trades, 1):
        res, ret_pct, exit_price = outcome(t, target)
        counts[res] = counts.get(res, 0) + 1
        if res in ("TP", "SL"):
            equity *= 1 + ret_pct / 100
        rows.append({
            "n": i,
            "target": target.upper(),
            "paris": t.get("paris"),
            "asset": t.get("asset"),
            "direction": t.get("direction"),
            "strategy": t.get("strategy") or "",
            "entry": t.get("entry"),
            "stop": t.get("stop"),
            "target_price": t.get(target),
            "result": res,
            "ret_pct": round(ret_pct, 4),
            "equity": round(equity, 4),
        })
    return equity, counts, rows


def write_svg(rows_tp1, rows_tp2, path):
    w, h, pad = 980, 430, 48
    vals = [100.0] + [r["equity"] for r in rows_tp1 + rows_tp2]
    lo, hi = min(vals), max(vals)
    if hi == lo:
        hi += 1
    n = max(len(rows_tp1), len(rows_tp2), 1)

    def pts(rows):
        out = []
        series = [{"n": 0, "equity": 100.0}] + rows
        for r in series:
            x = pad + (w - 2 * pad) * (r["n"] / n)
            y = h - pad - (h - 2 * pad) * ((r["equity"] - lo) / (hi - lo))
            out.append(f"{x:.1f},{y:.1f}")
        return " ".join(out)

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">
<rect width="100%" height="100%" fill="#111827"/>
<text x="{pad}" y="30" fill="#e5e7eb" font-family="Menlo, monospace" font-size="18">Simulation portefeuille IA - TP1 vs TP2</text>
<line x1="{pad}" y1="{h-pad}" x2="{w-pad}" y2="{h-pad}" stroke="#4b5563"/>
<line x1="{pad}" y1="{pad}" x2="{pad}" y2="{h-pad}" stroke="#4b5563"/>
<text x="{pad}" y="{h-14}" fill="#9ca3af" font-family="Menlo, monospace" font-size="12">0</text>
<text x="{w-pad-34}" y="{h-14}" fill="#9ca3af" font-family="Menlo, monospace" font-size="12">{n}</text>
<text x="12" y="{pad+4}" fill="#9ca3af" font-family="Menlo, monospace" font-size="12">{hi:.2f}€</text>
<text x="12" y="{h-pad+4}" fill="#9ca3af" font-family="Menlo, monospace" font-size="12">{lo:.2f}€</text>
<polyline points="{pts(rows_tp1)}" fill="none" stroke="#22c55e" stroke-width="3"/>
<polyline points="{pts(rows_tp2)}" fill="none" stroke="#38bdf8" stroke-width="3"/>
<text x="{w-230}" y="30" fill="#22c55e" font-family="Menlo, monospace" font-size="14">TP1 {rows_tp1[-1]['equity'] if rows_tp1 else 100:.2f}€</text>
<text x="{w-230}" y="52" fill="#38bdf8" font-family="Menlo, monospace" font-size="14">TP2 {rows_tp2[-1]['equity'] if rows_tp2 else 100:.2f}€</text>
</svg>
"""
    open(path, "w").write(svg)


def main():
    now = dt.datetime.now()
    year = int(sys.argv[1]) if len(sys.argv) > 1 else now.year
    month = int(sys.argv[2]) if len(sys.argv) > 2 else now.month
    asset = sys.argv[3].upper() if len(sys.argv) > 3 else None
    trades = load_trades(year, month, asset=asset, dedup=True)
    closed_or_known = [t for t in trades]
    eq1, c1, r1 = simulate(closed_or_known, "tp1")
    eq2, c2, r2 = simulate(closed_or_known, "tp2")
    suffix = f"_{asset}" if asset else ""
    csv_path = f"/Users/sam/trading/portfolio_sim_{year}_{month:02d}{suffix}.csv"
    svg_path = f"/Users/sam/trading/portfolio_sim_{year}_{month:02d}{suffix}.svg"
    with open(csv_path, "w", newline="") as f:
        fieldnames = list(r1[0].keys()) if r1 else ["n"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(r1)
        writer.writerows(r2)
    write_svg(r1, r2, svg_path)
    print(f"Trades IA uniques: {len(trades)}")
    print(f"TP1: {eq1:.2f}€ counts={c1}")
    print(f"TP2: {eq2:.2f}€ counts={c2}")
    print(f"CSV: {csv_path}")
    print(f"SVG: {svg_path}")


if __name__ == "__main__":
    main()
